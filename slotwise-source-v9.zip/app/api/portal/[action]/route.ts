import { getChatGPTUser } from "@/app/chatgpt-auth";
import { clearPortalCookie, createPortalCookie, hasPortalAccess, verifyPortalPin } from "@/app/portal-access.server";

export const dynamic = "force-dynamic";

type DebugStep = { phase: string; status: "success" | "failed"; detail: string; durationMs?: number };

function trace() {
  const started = Date.now(), requestId = crypto.randomUUID(), steps: DebugStep[] = [];
  return {
    add(step: DebugStep) { steps.push(step); console.info(`[portal-access:${requestId}]`, step); },
    result() { return { requestId, totalDurationMs: Date.now() - started, steps }; },
  };
}

function json(data: unknown, status = 200, cookie?: string) {
  const headers = new Headers({ "Content-Type": "application/json", "Cache-Control": "no-store, private", Pragma: "no-cache", "X-Content-Type-Options": "nosniff" });
  if (cookie) headers.append("Set-Cookie", cookie);
  return new Response(JSON.stringify(data), { status, headers });
}

async function identity(req: Request, write = false) {
  const user = await getChatGPTUser();
  if (!user) throw Object.assign(new Error("Sign in to your private Site first."), { status: 401, code: "site_auth_required" });
  if (req.headers.get("X-Portal-Request") !== "1") throw Object.assign(new Error("Unsupported request."), { status: 403, code: "missing_portal_header" });
  if (write && req.headers.get("origin") !== new URL(req.url).origin) throw Object.assign(new Error("This request must come from your portal."), { status: 403, code: "origin_mismatch" });
  return user;
}

export async function GET(req: Request, { params }: { params: Promise<{ action: string }> }) {
  const debug = trace();
  try {
    const user = await identity(req);
    debug.add({ phase: "identity", status: "success", detail: "Private Site identity confirmed" });
    if ((await params).action !== "session") return json({ error: "Endpoint not available.", debug: debug.result() }, 404);
    const unlocked = await hasPortalAccess(req, user.userId);
    debug.add({ phase: "pin_session", status: "success", detail: unlocked ? "Valid portal access cookie found" : "Portal is locked" });
    return json({ unlocked, debug: debug.result() });
  } catch (error) {
    const err = error as Error & { status?: number; code?: string };
    debug.add({ phase: "access", status: "failed", detail: err.message || "Access check failed" });
    return json({ error: err.message, code: err.code || "portal_access_error", debug: debug.result() }, err.status || 500);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ action: string }> }) {
  const debug = trace();
  try {
    const user = await identity(req, true);
    debug.add({ phase: "identity", status: "success", detail: "Private Site identity confirmed" });
    const { action } = await params;
    if (action === "lock") {
      debug.add({ phase: "lock", status: "success", detail: "Portal session cleared" });
      return json({ locked: true, debug: debug.result() }, 200, clearPortalCookie(req));
    }
    if (action !== "unlock") return json({ error: "Endpoint not available.", debug: debug.result() }, 404);
    const raw = await req.text();
    if (raw.length > 128) throw Object.assign(new Error("Invalid PIN request."), { status: 400, code: "invalid_request" });
    const body = JSON.parse(raw) as { pin?: unknown };
    if (typeof body.pin !== "string" || !/^\d{6}$/.test(body.pin)) throw Object.assign(new Error("Enter the 6-digit PIN."), { status: 400, code: "invalid_pin_format" });
    debug.add({ phase: "pin_input", status: "success", detail: "Six-digit PIN received; value not logged" });
    if (!(await verifyPortalPin(body.pin))) throw Object.assign(new Error("That PIN is incorrect."), { status: 401, code: "incorrect_pin" });
    debug.add({ phase: "pin_verify", status: "success", detail: "PIN verified on the server" });
    return json({ unlocked: true, debug: debug.result() }, 200, await createPortalCookie(req, user.userId));
  } catch (error) {
    const err = error as Error & { status?: number; code?: string };
    debug.add({ phase: "access", status: "failed", detail: err.message || "Access request failed" });
    return json({ error: err.message || "Unable to unlock the portal.", code: err.code || "portal_access_error", debug: debug.result() }, err.status || 500);
  }
}
