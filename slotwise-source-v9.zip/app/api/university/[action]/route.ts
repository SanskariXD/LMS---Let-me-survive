import { getChatGPTUser } from "@/app/chatgpt-auth";
import { hasPortalAccess, universityCredentials } from "@/app/portal-access.server";
import { normalizeAttendance, normalizeSemesters } from "@/lib/university-domain";

export const dynamic = "force-dynamic";

const BASE = "http://35.200.229.112/api";
const SECURE_COOKIE = "__Secure-university_session";
const LOCAL_COOKIE = "university_session";

type StepStatus = "success" | "failed" | "skipped";
type DebugStep = { phase: string; label: string; status: StepStatus; detail: string; durationMs?: number; httpStatus?: number };
type Probe = { endpoint: string; received: boolean; responseType?: string; itemCount?: number; topLevelFields?: number; httpStatus?: number };

class ApiError extends Error {
  constructor(message: string, public status = 502, public code = "portal_error") { super(message); }
}

function createTrace() {
  const started = Date.now(), requestId = crypto.randomUUID(), steps: DebugStep[] = [];
  return {
    add(step: DebugStep) { steps.push(step); console.info(`[university:${requestId}]`, step); },
    result() { return { requestId, totalDurationMs: Date.now() - started, steps }; },
  };
}

function cookiePolicy(req: Request) {
  const secure = new URL(req.url).protocol === "https:";
  return { name: secure ? SECURE_COOKIE : LOCAL_COOKIE, flags: `Path=/api/university; HttpOnly; SameSite=Strict${secure ? "; Secure" : ""}` };
}

function json(data: unknown, status = 200, cookie?: string) {
  const headers = new Headers({ "Content-Type": "application/json", "Cache-Control": "no-store, private", Pragma: "no-cache", "X-Content-Type-Options": "nosniff" });
  if (cookie) headers.append("Set-Cookie", cookie);
  return new Response(JSON.stringify(data), { status, headers });
}

function clearCookie(req: Request) {
  const cookie = cookiePolicy(req);
  return `${cookie.name}=; ${cookie.flags}; Max-Age=0`;
}

function claims(token: string): Record<string, unknown> {
  try {
    const part = token.split(".")[1];
    const padded = part.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(part.length / 4) * 4, "=");
    return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(padded), (char) => char.charCodeAt(0))));
  } catch { throw new ApiError("The university returned an invalid session token.", 401, "invalid_token"); }
}

function tokenFrom(req: Request) {
  const cookie = cookiePolicy(req);
  const entry = (req.headers.get("cookie") || "").split(";").map((item) => item.trim()).find((item) => item.startsWith(`${cookie.name}=`));
  if (!entry) return null;
  try {
    const token = decodeURIComponent(entry.slice(cookie.name.length + 1)), payload = claims(token);
    return typeof payload.exp === "number" && payload.exp * 1000 > Date.now() ? token : null;
  } catch { return null; }
}

async function upstream(path: string, options: { token?: string; body?: object } = {}) {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (options.body) headers["Content-Type"] = "application/json";
  if (options.token) headers["x-access-token"] = options.token;
  let response: Response;
  try {
    response = await fetch(`${BASE}${path}`, { method: options.body ? "POST" : "GET", redirect: "error", signal: AbortSignal.timeout(15000), headers, ...(options.body ? { body: JSON.stringify(options.body) } : {}) });
  } catch (error) {
    const timedOut = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
    throw new ApiError(timedOut ? "The university server did not respond within 15 seconds." : "The university server could not be reached from this portal.", 504, timedOut ? "upstream_timeout" : "upstream_network_error");
  }
  if (!response.ok) throw new ApiError(`University endpoint returned HTTP ${response.status}.`, response.status, "upstream_http_error");
  try { return await response.json(); }
  catch { throw new ApiError("The university returned a non-JSON response.", 502, "invalid_upstream_json"); }
}

async function runPhase<T>(trace: ReturnType<typeof createTrace>, phase: string, label: string, task: () => Promise<T> | T, detail?: (value: T) => string) {
  const started = Date.now();
  try {
    const value = await task();
    trace.add({ phase, label, status: "success", detail: detail ? detail(value) : "Completed", durationMs: Date.now() - started });
    return value;
  } catch (error) {
    const err = error instanceof ApiError ? error : new ApiError(error instanceof Error ? error.message : "Unexpected portal error.");
    trace.add({ phase, label, status: "failed", detail: err.message, durationMs: Date.now() - started, ...(err.code === "upstream_http_error" ? { httpStatus: err.status } : {}) });
    throw err;
  }
}

function summary(endpoint: string, value: unknown): Probe {
  if (Array.isArray(value)) return { endpoint, received: true, responseType: "array", itemCount: value.length };
  if (value && typeof value === "object") return { endpoint, received: true, responseType: "object", topLevelFields: Object.keys(value as object).length };
  return { endpoint, received: true, responseType: value === null ? "null" : typeof value };
}

async function probe(trace: ReturnType<typeof createTrace>, endpoint: string, label: string, token: string) {
  const started = Date.now();
  try {
    const value = await upstream(endpoint, { token }), result = summary(endpoint, value);
    trace.add({ phase: `probe:${endpoint}`, label, status: "success", detail: result.responseType === "array" ? `Response received (${result.itemCount} items)` : `Response received (${result.responseType})`, durationMs: Date.now() - started });
    return { result, value };
  } catch (error) {
    const err = error instanceof ApiError ? error : new ApiError("Probe failed.");
    trace.add({ phase: `probe:${endpoint}`, label, status: "failed", detail: err.message, durationMs: Date.now() - started, httpStatus: err.status });
    return { result: { endpoint, received: false, httpStatus: err.status } as Probe, value: null };
  }
}

function nestedRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const record = value as Record<string, unknown>;
  for (const key of ["user", "student", "data", "profile"]) if (record[key] && typeof record[key] === "object" && !Array.isArray(record[key])) return record[key] as Record<string, unknown>;
  return record;
}

function firstString(record: Record<string, unknown>, keys: string[]) {
  for (const key of keys) if (typeof record[key] === "string" && String(record[key]).trim()) return String(record[key]).trim();
  return "";
}

function enrollmentFrom(username: string, ...records: Record<string, unknown>[]) {
  for (const record of records) {
    const value = firstString(record, ["enrollment_no", "enrollment_number", "enrollment", "student_id", "username"]);
    const candidate = value.includes("@") ? value.split("@")[0] : value;
    if (/^[a-z0-9-]{3,40}$/i.test(candidate)) return candidate;
  }
  const prefix = username.split("@")[0];
  return /^[a-z0-9-]{3,40}$/i.test(prefix) ? prefix : null;
}

async function automaticLogin(trace: ReturnType<typeof createTrace>) {
  const credentials = universityCredentials();
  trace.add({ phase: "credentials", label: "Load automatic login configuration", status: "success", detail: "Server-side credentials found; values are not logged" });
  const loginData = await runPhase(trace, "login", "Sign in to university", () => upstream("/auth/login", { body: credentials }), () => "Login response received");
  if (!loginData || typeof loginData !== "object" || typeof (loginData as Record<string, unknown>).token !== "string") throw new ApiError("The university did not return a supported session token.", 502, "missing_token");
  const record = loginData as Record<string, unknown>, token = record.token as string, payload = claims(token);
  if (typeof payload.exp !== "number" || payload.exp * 1000 <= Date.now()) throw new ApiError("The university returned an expired session.", 401, "expired_token");
  trace.add({ phase: "token", label: "Validate university session", status: "success", detail: "JWT received and expiry validated; token not logged" });
  return { token, loginUser: nestedRecord(record.user), maxAge: Math.min(3600, Math.max(1, Math.floor(payload.exp - Date.now() / 1000))) };
}

async function readSession(token: string, trace: ReturnType<typeof createTrace>, loginUser: Record<string, unknown> = {}) {
  const authMe = await runPhase(trace, "auth_me", "Confirm university session", () => upstream("/auth/me", { token }), (value) => `Response received (${summary("/auth/me", value).responseType})`);
  const me = nestedRecord(authMe), tokenData = claims(token);
  const username = firstString(loginUser, ["username", "email"]) || firstString(me, ["username", "email"]) || firstString(tokenData, ["username", "email"]) || "Student";
  const enrollment = enrollmentFrom(username, loginUser, me, tokenData);
  const endpoints: Array<[string, string]> = [
    ["/system-config/course-registration-status", "Check course registration status"],
    ["/course-withdrawal/withdrawal-status", "Check withdrawal status"],
    ["/schools", "Check schools endpoint"],
    ["/programs", "Check programs endpoint"],
    ["/slots", "Check slots endpoint"],
    ["/attendance/student/semesters", "Check attendance semesters"],
  ];
  if (enrollment) endpoints.push([`/students/${encodeURIComponent(enrollment)}`, "Check student profile"]);
  const results = await Promise.all(endpoints.map(([endpoint, label]) => probe(trace, endpoint, label, token)));
  trace.add({ phase: "probe:/courses", label: "Check courses endpoint", status: "skipped", detail: "Skipped for now because the observed endpoint returns HTTP 403" });
  const probes = [summary("/auth/me", authMe), ...results.map((entry) => entry.result), { endpoint: "/courses", received: false, httpStatus: 403 } as Probe];
  const profile = nestedRecord(results.find((entry) => entry.result.endpoint.startsWith("/students/"))?.value);
  const semesterValue = results.find((entry) => entry.result.endpoint === "/attendance/student/semesters")?.value;
  let semesters: ReturnType<typeof normalizeSemesters> = [];
  try { semesters = normalizeSemesters(semesterValue); }
  catch { trace.add({ phase: "semesters", label: "Interpret semester response", status: "skipped", detail: "Response arrived but its shape is not mapped yet" }); }
  return {
    user: {
      name: firstString(profile, ["student_name", "full_name", "name"]) || firstString(loginUser, ["full_name", "name"]) || firstString(me, ["full_name", "name"]) || username,
      username,
      enrollment,
      program: firstString(profile, ["program_name", "program"]) || null,
    },
    semesters,
    profileAvailable: Object.keys(profile).length > 0,
    probes,
  };
}

async function guard(req: Request, write = false) {
  const user = await getChatGPTUser();
  if (!user) throw new ApiError("Sign in to your private Site first.", 401, "site_auth_required");
  if (!(await hasPortalAccess(req, user.userId))) throw new ApiError("Unlock the portal with your PIN first.", 401, "portal_pin_required");
  if (req.headers.get("X-Portal-Request") !== "1") throw new ApiError("Unsupported request.", 403, "missing_portal_header");
  if (write && req.headers.get("origin") !== new URL(req.url).origin) throw new ApiError("This request must come from your portal.", 403, "origin_mismatch");
}

function failure(error: unknown, trace: ReturnType<typeof createTrace>, req: Request) {
  const err = error instanceof ApiError ? error : new ApiError(error instanceof Error ? error.message : "Unable to complete the portal request.");
  return json({ error: err.message, code: err.code, debug: trace.result() }, err.status, err.code.includes("token") || err.code.startsWith("upstream") ? clearCookie(req) : undefined);
}

export async function GET(req: Request, { params }: { params: Promise<{ action: string }> }) {
  const trace = createTrace();
  try {
    await runPhase(trace, "portal", "Validate PIN-protected portal session", () => guard(req));
    const { action } = await params;
    if (!["session", "attendance"].includes(action)) return json({ error: "Endpoint not available.", debug: trace.result() }, 404);
    let token = tokenFrom(req), loginUser: Record<string, unknown> = {}, maxAge: number | null = null;
    if (!token) {
      trace.add({ phase: "cookie", label: "Read university session cookie", status: "skipped", detail: "No valid university session found; starting automatic login" });
      const login = await automaticLogin(trace); token = login.token; loginUser = login.loginUser; maxAge = login.maxAge;
    } else trace.add({ phase: "cookie", label: "Read university session cookie", status: "success", detail: "Protected university session found; token not logged" });
    if (action === "session") {
      let session;
      try { session = await readSession(token, trace, loginUser); }
      catch (error) {
        if (maxAge !== null || !(error instanceof ApiError) || ![401, 403].includes(error.status)) throw error;
        trace.add({ phase: "relogin", label: "Renew rejected university session", status: "success", detail: "Stored session was rejected; retrying once" });
        const login = await automaticLogin(trace); token = login.token; loginUser = login.loginUser; maxAge = login.maxAge;
        session = await readSession(token, trace, loginUser);
      }
      const cookie = cookiePolicy(req);
      return json({ ...session, debug: trace.result() }, 200, maxAge === null ? undefined : `${cookie.name}=${encodeURIComponent(token)}; ${cookie.flags}; Max-Age=${maxAge}`);
    }
    const url = new URL(req.url), year = url.searchParams.get("slot_year"), type = url.searchParams.get("semester_type");
    if (!year || !type || year.length > 32 || type.length > 32) throw new ApiError("Choose a valid semester first.", 400, "invalid_semester");
    const courses = await runPhase(trace, "attendance", "Load attendance records", async () => normalizeAttendance(await upstream(`/attendance/student/my-attendance?${new URLSearchParams({ slot_year: year, semester_type: type })}`, { token })), (value) => `Response mapped to ${value.length} course records`);
    const cookie = cookiePolicy(req);
    return json({ courses, fetchedAt: new Date().toISOString(), debug: trace.result() }, 200, maxAge === null ? undefined : `${cookie.name}=${encodeURIComponent(token)}; ${cookie.flags}; Max-Age=${maxAge}`);
  } catch (error) { return failure(error, trace, req); }
}

export async function POST(req: Request, { params }: { params: Promise<{ action: string }> }) {
  const trace = createTrace();
  try {
    await runPhase(trace, "portal", "Validate PIN-protected portal session", () => guard(req, true));
    if ((await params).action !== "logout") return json({ error: "Endpoint not available.", debug: trace.result() }, 404);
    trace.add({ phase: "logout", label: "Clear university session", status: "success", detail: "Automatic login will run again on the next portal load" });
    return json({ disconnected: true, debug: trace.result() }, 200, clearCookie(req));
  } catch (error) { return failure(error, trace, req); }
}
