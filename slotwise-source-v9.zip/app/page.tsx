import { redirect } from 'next/navigation';
export default function Home(){redirect('/slotwise/index.html')}
