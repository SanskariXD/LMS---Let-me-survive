import { env } from "cloudflare:workers";

const SECURE_COOKIE = "__Secure-portal_access";
const LOCAL_COOKIE = "portal_access";
const SESSION_SECONDS = 12 * 60 * 60;

type RuntimeEnv = Record<string, string | undefined>;

function runtimeValue(name: string) {
  return (env as unknown as RuntimeEnv)[name];
}

function cookiePolicy(req: Request) {
  const secure = new URL(req.url).protocol === "https:";
  return {
    name: secure ? SECURE_COOKIE : LOCAL_COOKIE,
    flags: `Path=/; HttpOnly; SameSite=Strict${secure ? "; Secure" : ""}`,
  };
}

function bytes(value: string) {
  return new TextEncoder().encode(value);
}

function base64Url(value: Uint8Array) {
  let binary = "";
  for (const byte of value) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function signature(payload: string) {
  const secret = runtimeValue("PORTAL_SESSION_SECRET");
  if (!secret) throw new Error("Portal session secret is not configured.");
  const key = await crypto.subtle.importKey("raw", bytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return base64Url(new Uint8Array(await crypto.subtle.sign("HMAC", key, bytes(payload))));
}

async function equal(a: string, b: string) {
  const [left, right] = await Promise.all([crypto.subtle.digest("SHA-256", bytes(a)), crypto.subtle.digest("SHA-256", bytes(b))]);
  const x = new Uint8Array(left), y = new Uint8Array(right);
  if (x.length !== y.length) return false;
  let difference = 0;
  for (let index = 0; index < x.length; index++) difference |= x[index] ^ y[index];
  return difference === 0;
}

export async function verifyPortalPin(pin: string) {
  const expected = runtimeValue("PORTAL_PIN");
  if (!expected) throw new Error("Portal PIN is not configured.");
  return equal(pin, expected);
}

export async function createPortalCookie(req: Request, userId: string) {
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const payload = base64Url(bytes(JSON.stringify({ userId, expires })));
  const token = `${payload}.${await signature(payload)}`;
  const cookie = cookiePolicy(req);
  return `${cookie.name}=${encodeURIComponent(token)}; ${cookie.flags}; Max-Age=${SESSION_SECONDS}`;
}

export function clearPortalCookie(req: Request) {
  const cookie = cookiePolicy(req);
  return `${cookie.name}=; ${cookie.flags}; Max-Age=0`;
}

export async function hasPortalAccess(req: Request, userId: string) {
  const cookie = cookiePolicy(req);
  const entry = (req.headers.get("cookie") || "").split(";").map((item) => item.trim()).find((item) => item.startsWith(`${cookie.name}=`));
  if (!entry) return false;
  try {
    const token = decodeURIComponent(entry.slice(cookie.name.length + 1));
    const [payload, suppliedSignature] = token.split(".");
    if (!payload || !suppliedSignature || !(await equal(suppliedSignature, await signature(payload)))) return false;
    const raw = payload.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(payload.length / 4) * 4, "=");
    const parsed = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(raw), (character) => character.charCodeAt(0))));
    return parsed.userId === userId && typeof parsed.expires === "number" && parsed.expires > Date.now() / 1000;
  } catch {
    return false;
  }
}

export function universityCredentials() {
  const username = runtimeValue("UNIVERSITY_USERNAME");
  const password = runtimeValue("UNIVERSITY_PASSWORD");
  if (!username || !password) throw new Error("Automatic university login is not configured.");
  return { username, password };
}
