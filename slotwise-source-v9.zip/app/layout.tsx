import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sanskari — Student Space",
  description: "Your personal campus portal for attendance, courses and timetable planning.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
